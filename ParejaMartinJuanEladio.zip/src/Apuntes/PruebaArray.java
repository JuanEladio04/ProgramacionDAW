package Apuntes;

import tutorialJava.Utils;

public class PruebaArray {

	public static void main(String[] args) {
		
		int num1[] = new int [10];
		
		for (int i = 0; i < num1.length; i++) {
			num1[i] = (int) Math.round(Math.random() * 100);
			System.out.println(num1);
		}
		
		
		
		
		
		

	}

}
